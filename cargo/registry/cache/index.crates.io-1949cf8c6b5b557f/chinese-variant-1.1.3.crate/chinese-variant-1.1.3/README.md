Chinese Variant
====================

[![CI](https://github.com/magiclen/chinese-variant/actions/workflows/ci.yml/badge.svg)](https://github.com/magiclen/chinese-variant/actions/workflows/ci.yml)

An enum to represent the variants (traditional and simple) of the Chinese Language.

## Crates.io

https://crates.io/crates/chinese-variant

## Documentation

https://docs.rs/chinese-variant

## License

[MIT](LICENSE)
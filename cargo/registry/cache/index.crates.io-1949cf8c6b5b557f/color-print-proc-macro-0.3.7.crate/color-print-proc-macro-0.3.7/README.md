This internal library provides the procedural macros needed by the crate [`color-print`].

[`color-print`]: https://crates.io/crates/color-print

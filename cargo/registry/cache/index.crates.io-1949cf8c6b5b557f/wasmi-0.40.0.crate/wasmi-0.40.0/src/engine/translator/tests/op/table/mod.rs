use super::*;

mod table_copy;
mod table_fill;
mod table_get;
mod table_grow;
mod table_init;
mod table_set;
mod table_size;

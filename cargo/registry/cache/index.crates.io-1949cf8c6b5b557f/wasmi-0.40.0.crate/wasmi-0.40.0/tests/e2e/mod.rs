//! End-to-end tests for Wasmi.

mod v1;

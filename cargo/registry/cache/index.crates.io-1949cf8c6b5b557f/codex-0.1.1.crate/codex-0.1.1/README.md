# codex
[![Crates.io](https://img.shields.io/crates/v/codex.svg)](https://crates.io/crates/codex)
[![Documentation](https://docs.rs/codex/badge.svg)](https://docs.rs/codex)

Human-friendly notation for Unicode symbols.

## License
This crate is licensed under the Apache 2.0 license.
